 var app = angular.module('myApp', []);
        app.controller('StoreController', function($scope){
        //$scope.products = productsData;


        $scope.categorys = [
                                {Product_name:'PName'},
                                {New_Price:'NPrice'},
                                {Old_Price:'OPrice'}
                            ];
        
        $scope.products = [
        { 
            Product_name:'PName',
            New_Price:'NPrice',
            Old_Price:'OPrice',
            name: 'Dummy Products Name 01',
            newprice:200.00,
            price: 2550.0,
            image: ''
        },
        {
             Product_name:'PName',
            New_Price:'NPrice',
            Old_Price:'OPrice',
            name: 'Dummy Products Name 02',
            newprice:210.00,
            price: 1644.5,
            image: ''
        },
        {
             Product_name:'PName',
            New_Price:'NPrice',
            Old_Price:'OPrice',
            name: 'Dummy Products Name 03',
            newprice:100.00,
            price: 144.5,
            image: ''
        },
        {
             Product_name:'PName',
            New_Price:'NPrice',
            Old_Price:'OPrice',
            name: 'Dummy Products Name 04',
            newprice:499.00,
            price: 4515,
            image: ''
        },
        {
             Product_name:'PName',
            New_Price:'NPrice',
            Old_Price:'OPrice',
            name: 'Dummy Products Name 05',
            newprice:240.00,
            price: 1100.43,
            image: ''
        },

        {
             Product_name:'PName',
            New_Price:'NPrice',
            Old_Price:'OPrice',
            name: 'Dummy Products Name 06',
            newprice:100.00,
            price: 999.9,
            image: ''
        }
        ];

        });


    app.filter('ProdutFilter', function() 
    {
          return function(x)
          {
                var i, c, txt = "";
                for (i = 0; i < x.length; i++) {
                  c = x[i];
                  if (i % 2 == 0) {
                    c = c.toUpperCase();
                  }
              txt += c;
            }
            return txt;
          };
    });